package nl.novi.HotelApp;

public class ArraySum {

    public static void main(String[] args) {

        int[] data = new int[4];
        data [0] = 1;
        data [1] = 5;
        data [2] = 3;
        data [3] = 1;

        System.out.println("Het resultaat van het optellen van een array: " + add(data));

    }

    public static int add(int[] data) {

        int sum = 0;
        for (int datum : data) {
            sum = sum + datum;
        }

        return sum;
    }
}