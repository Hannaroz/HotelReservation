package nl.novi.HotelApp;

public class Person {



}
