package nl.novi.HotelApp;

public enum Gender {
    MALE,
    FEMALE
}
