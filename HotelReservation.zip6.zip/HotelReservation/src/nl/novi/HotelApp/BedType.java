package nl.novi.HotelApp;

public enum BedType {

    SINGLE,
    DOUBLE,
    KING_SIZE

}
