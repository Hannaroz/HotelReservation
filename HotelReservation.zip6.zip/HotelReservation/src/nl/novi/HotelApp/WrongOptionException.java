package nl.novi.HotelApp;

public class WrongOptionException extends ReservationCustomException{

    public int getCode() {
        return code;
    }

    private int code = 101;


    public WrongOptionException(String message)  {
        super(message);



}
}
