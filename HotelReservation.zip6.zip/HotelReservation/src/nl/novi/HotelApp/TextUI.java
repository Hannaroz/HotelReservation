package nl.novi.HotelApp;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TextUI {

    GuestService guestService = new GuestService();
// static
    public void readNewGuestData(Scanner input) {
        System.out.println("Maak een nieuwe gast aan");
        try {
            System.out.print("Voer naam in: ");
            String firstName = input.next();
            System.out.print("Voer achternaam in: ");
            String lastName = input.next();
            System.out.print("Voer leeftijd in: ");
            int age = input.nextInt();
            System.out.println("Voer geslacht in (1. Man 2. Vrouw): ");

            int genderOption = input.nextInt();

            if(genderOption != 1 && genderOption !=2)  {
                throw new WrongOptionException("Wrong option in gender selection");
            }
            Guest newGuest = guestService.createNewGuest(firstName, lastName, age, genderOption);
            System.out.println(newGuest.getInfo());

        } catch (InputMismatchException e) {
            throw new OnlyNumberException("Use only numberswhen choosing gender");

        }

        }
}
