package nl.novi.HotelApp;

import java.util.InputMismatchException;
import java.util.Scanner;

public class App {
    private static TextUI textUI = new TextUI();

    public static void main(String[] args) {

        String hotelName = "Overlook";
        int systemVersion = 2;
        boolean isDeveloperVersion = true;

        showSystemInfo(hotelName, systemVersion, isDeveloperVersion);

        Scanner input = new Scanner(System.in);

        try{
            performAction(input);
        } catch(WrongOptionException | OnlyNumberException e){
            System.out.println("Er is een onverwachte fout opgetreden");
            System.out.println("Foutcode " + e.getCode());
            System.out.println("Foutmelding: " + e.getMessage());
            e.printStackTrace();
        }  catch (Exception e) {
            System.out.println("Er is een onverwachte fout opgetreden");
            System.out.println("Onbekende foutcode");
            System.out.println("Unknown exception");
            e.printStackTrace();
        } finally {
            System.out.println("Ik stop de applicatie");

        }

    }

    private static void performAction(Scanner input) {
        int option = getActionFromUser(input);

        if (option == 1) {
            textUI.readNewGuestData(input);
        } else if (option == 2) {
            Room newRoom = createNewRoom(input);
        } else if (option == 3) {
            System.out.println("Optie 3. geselecteerd");
        } else {
            throw new WrongOptionException("Wrong option in main menu");
        }
    }

    private static void showSystemInfo(String hotelName, int systemVersion, boolean isDeveloperVersion) {

        System.out.print("Witam w systemie rezerwacji dla hotelu " + hotelName);
        System.out.print("Aktualna wersja systemu: " + systemVersion);
        System.out.print("Wersja developerska " + isDeveloperVersion);

        System.out.println("\n=============================\n");

    }

    private static int getActionFromUser(Scanner in) {
        System.out.println("1. Een nieuwe gast toevoegen");
        System.out.println("2. Een nieuwe kamer toevoegen");
        System.out.println("3. Zoek een gast ");
        System.out.println("Kies optie: ");

        int actionNumber = 0;

        try {
            actionNumber = in.nextInt();

        } catch (InputMismatchException e) {
            throw new OnlyNumberException("Use only numbers in main menu");
        }
        return actionNumber;
    }

    private static Guest createNewGuest(Scanner input) {
        try {
            System.out.println("Maak een nieuwe gast aan");
            System.out.print("Voer naam in: ");
            String firstName = input.next();
            System.out.print("Voer achternaam in: ");
            String lastName = input.next();
            System.out.print("Voer leeftijd in: ");
            int age = input.nextInt();
            System.out.println("Voer geslacht in (1. Man 2. Vrouw): ");
            int genderOption = input.nextInt();
            Gender gender = Gender.FEMALE;
            if (genderOption == 1) {
                gender = Gender.MALE;
            } else if (genderOption == 2) {
                gender = Gender.FEMALE;
            } else {
                throw new WrongOptionException("Wrong option in gender selection");
            }

            Guest newGuest = new Guest(firstName, lastName, age, gender);
            System.out.println(newGuest.getInfo());
            return newGuest;
        } catch (InputMismatchException e) {
           throw new OnlyNumberException("Use only numberswhen choosing gender");
        }

    }

    private static Room createNewRoom(Scanner input) {
        System.out.println("Nieuwe kamer maken");
        try {
            System.out.println("Voer het nummer voor de nieuwe kamer in: ");
            int number = input.nextInt();
            BedType bedType[] = chooseBedType(input);
            Room newRoom = new Room(number, bedType);
            System.out.println(newRoom.getInfo());
            return newRoom;

        } catch (InputMismatchException e) {
            throw new OnlyNumberException("Use numbers when creating new room");

        }
    }

    static private BedType[] chooseBedType(Scanner input) {
        System.out.println("Hoeveel bedden in de kamer?");
        int bedNumber = input.nextInt();
        BedType[] bedTypes = new BedType[bedNumber];

        for (int i = 0; i < bedNumber; i = i + 1) {
            System.out.println("Typen bedden: ");
            System.out.println("\t1. Enkel");
            System.out.println("\t2. Double");
            System.out.println("\t3. King Size ");

            BedType bedType = BedType.SINGLE;

            int bedTypeOption = input.nextInt();

            if (bedTypeOption == 1) {
                bedType = BedType.SINGLE;
            } else if (bedTypeOption == 2) {
                bedType = BedType.DOUBLE;
            } else if (bedTypeOption == 3) {
                bedType = BedType.KING_SIZE;
            } else {
                throw new WrongOptionException("Wrong option when selecting bed type");
            }
            bedTypes[i] = bedType;

        }
        return bedTypes;

    }
}