package nl.novi.HotelApp;

public class GuestRepository {

    public Guest createNewGuest(String firstName, String lastName, int age, Gender gender) {

        Guest newGuest = new Guest(firstName, lastName, age, gender);

        return newGuest;


    }
}



