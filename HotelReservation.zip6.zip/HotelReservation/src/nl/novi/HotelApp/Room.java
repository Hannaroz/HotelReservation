package nl.novi.HotelApp;

public class Room {

    private int number;
    private BedType[] beds;




    public Room(int number, BedType[] beds) {
        this.number = number;
        this.beds = beds;

    }
    public String getInfo() {



        String bedInfo = "Soorten bedden in de kamer:\n";


        for(BedType bed: beds) {
           bedInfo = bedInfo + "\t" + bed + "\n";

        }

        return String.format("Nieuwe kamer toegevoegd - numer: %d %s", this.number,bedInfo);   //this.beds.toString());
    }

}
